hnn
===

haskell neural network library

[![Build Status](https://secure.travis-ci.org/alpmestan/hnn.png?branch=master)](http://travis-ci.org/alpmestan/hnn)

You can find online documentation of approximately the latest version of this repo [here](http://alpmestan.com/hnn/) or [on hackage](http://hackage.haskell.org/package/hnn-0.2.0.0). See the _examples/_ directory to see how to use the library or the `AI.HNN.FF.Network` module for a tutorial. 

Also, feel free to join _#haskell-math_ on irc.freenode.net if you have any question, or if you just want to chat about the library, some potential use you want to make of it, etc.

This library is written and maintained by Alp Mestanogullari <alpmestan@gmail.com> and Gatlin Johnson <rokenrol@gmail.com>.
