* Implement cross validation and propose it as a primitive backprop function
* Implement backprop-with-momentum
* Implement conjugate gradient backprop
* Investigate rprop
* Port hnn to accelerate-blas when it's ready for prime time :-)